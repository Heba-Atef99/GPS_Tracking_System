#include "stdint.h"
#include "C:/Keil/TExaSware/tm4c123gh6pm.h"

void Systick_Wait_1ms ();

void Systick_Wait_Multiples_1ms(uint32_t time);